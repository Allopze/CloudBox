# CloudBox v1.0.0

## Quick Start

### 1. Backend Setup
```bash
cd backend
cp .env.example .env
# Edit .env with your database and Redis configuration
npm install --production
npm run db:migrate
npm run start
```

### 2. Frontend Setup
```bash
cd frontend
npm run serve
```

Or serve the `frontend/dist` folder with any static file server (nginx, apache, etc.)

## Requirements
- Node.js >= 18
- PostgreSQL
- Redis (optional, for caching and job queues)

## Environment Variables
See `backend/.env.example` for all available configuration options.
